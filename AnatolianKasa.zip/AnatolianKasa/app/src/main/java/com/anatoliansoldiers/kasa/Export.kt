package com.anatoliansoldiers.kasa

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.File
import java.time.LocalDate
import java.time.YearMonth

class Col(val x: Float, val w: Float, val right: Boolean = false)

class PdfBuilder {
    private val doc = PdfDocument()
    private var page: PdfDocument.Page? = null
    private var canvas: Canvas? = null
    private var y = 0f
    private var pageNo = 0
    private val pageW = 595
    private val pageH = 842
    private val margin = 40f

    private val h1 = Paint().apply { textSize = 16f; typeface = Typeface.DEFAULT_BOLD; color = Color.BLACK; isAntiAlias = true }
    private val h2 = Paint().apply { textSize = 12f; typeface = Typeface.DEFAULT_BOLD; color = Color.rgb(150, 100, 0); isAntiAlias = true }
    private val body = Paint().apply { textSize = 9f; color = Color.BLACK; isAntiAlias = true }
    private val bold = Paint().apply { textSize = 9f; typeface = Typeface.DEFAULT_BOLD; color = Color.BLACK; isAntiAlias = true }
    private val line = Paint().apply { color = Color.LTGRAY; strokeWidth = 0.5f }

    fun newPage() {
        finishPage()
        pageNo++
        val p = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
        page = p
        canvas = p.canvas
        y = margin + 10f
    }

    private fun finishPage() {
        page?.let { doc.finishPage(it) }
        page = null
        canvas = null
    }

    private fun ensure(h: Float) {
        if (page == null || y + h > pageH - margin) newPage()
    }

    fun gap(h: Float) { y += h }

    fun title(t: String) {
        ensure(26f)
        canvas!!.drawText(t, margin, y, h1)
        y += 22f
    }

    fun section(t: String) {
        ensure(34f)
        y += 8f
        canvas!!.drawText(t, margin, y, h2)
        y += 8f
        canvas!!.drawLine(margin, y, pageW - margin, y, line)
        y += 12f
    }

    fun text(t: String) {
        ensure(14f)
        canvas!!.drawText(t, margin, y, body)
        y += 13f
    }

    fun row(cells: List<String>, cols: List<Col>, isBold: Boolean = false) {
        ensure(14f)
        val paint = if (isBold) bold else body
        cells.forEachIndexed { i, s ->
            val c = cols[i]
            paint.textAlign = if (c.right) Paint.Align.RIGHT else Paint.Align.LEFT
            canvas!!.drawText(fit(s, paint, c.w), if (c.right) c.x + c.w else c.x, y, paint)
        }
        paint.textAlign = Paint.Align.LEFT
        y += 13f
    }

    private fun fit(s: String, paint: Paint, w: Float): String {
        if (paint.measureText(s) <= w) return s
        var t = s
        while (t.isNotEmpty() && paint.measureText("$t…") > w) t = t.dropLast(1)
        return "$t…"
    }

    fun save(file: File) {
        finishPage()
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
    }
}

object Export {
    fun exportDir(ctx: Context): File = File(ctx.cacheDir, "exports").also { it.mkdirs() }

    private fun cell(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
    private fun num(v: Double) = String.format(TR, "%.2f", v)
    private fun csvLine(items: List<Any>) =
        items.joinToString(";") { if (it is Double) num(it) else cell(it.toString()) } + "\r\n"

    private fun stateText(s: MonthState) = when (s) {
        MonthState.PAID -> "Ödendi"
        MonthState.OVERDUE -> "Gecikmede"
        MonthState.DUE -> "Bekliyor"
        MonthState.EXEMPT -> "Muaf"
        MonthState.FUTURE -> ""
        MonthState.NA -> "-"
    }

    /** Excel'de doğrudan açılır (Türkçe Excel için ; ayraçlı, UTF-8 BOM'lu). */
    fun duesCsv(ctx: Context, d: AppData, year: Int): File {
        val today = LocalDate.now()
        val sb = StringBuilder("﻿")
        sb.append(
            csvLine(
                listOf("Ad Soyad", "Yol Adı", "Chapter", "Rütbe", "Durum", "Aylık aidat") +
                    TR_MONTHS_SHORT.map { "$it $year" } +
                    listOf("Geçmiş borç", "Güncel ay borcu", "Ekstra borç", "Alacak", "Toplam borç")
            )
        )
        d.members.sortedBy { it.fullName }.forEach { m ->
            val b = Calc.balance(d, m, today)
            val months = (1..12).map { stateText(Calc.monthState(d, m, YearMonth.of(year, it), today)) }
            sb.append(
                csvLine(
                    listOf(m.fullName, m.roadName, m.chapter, m.rankLabel(), m.status.label, m.monthlyDues) +
                        months +
                        listOf(b.past, b.current, b.extra, b.credit, b.total)
                )
            )
        }
        val f = File(exportDir(ctx), "aidat-tablosu-$year.csv")
        f.writeText(sb.toString(), Charsets.UTF_8)
        return f
    }

    fun ledgerCsv(ctx: Context, d: AppData, year: Int, month: Int?): File {
        val (from, to) = range(year, month)
        val sb = StringBuilder("﻿")
        sb.append(csvLine(listOf("Tarih", "Tür", "Kalem", "Açıklama", "Tutar", "Hesap", "Kasa")))
        d.ledger.filter { Calc.inRange(it, from, to) }
            .sortedBy { it.date }
            .forEach { e ->
                sb.append(
                    csvLine(
                        listOf(
                            fmtDate(e.date), if (e.income) "Gelir" else "Gider", e.category, e.description,
                            if (e.income) e.amount else -e.amount, e.account.label, scopeName(d.settings, e.scope)
                        )
                    )
                )
            }
        val f = File(exportDir(ctx), "kasa-hareketleri-${fileLabel(year, month)}.csv")
        f.writeText(sb.toString(), Charsets.UTF_8)
        return f
    }

    private fun range(year: Int, month: Int?): Pair<LocalDate, LocalDate> {
        val from = if (month == null) LocalDate.of(year, 1, 1) else LocalDate.of(year, month, 1)
        val to = if (month == null) LocalDate.of(year, 12, 31) else from.withDayOfMonth(from.lengthOfMonth())
        return from to to
    }

    private fun fileLabel(year: Int, month: Int?) =
        if (month == null) "$year" else "$year-${month.toString().padStart(2, '0')}"

    fun pdfReport(ctx: Context, d: AppData, year: Int, month: Int?): File {
        val (from, to) = range(year, month)
        val label = if (month == null) "$year yılı" else "${TR_MONTHS[month - 1]} $year"
        val today = LocalDate.now()
        val pdf = PdfBuilder()
        pdf.newPage()
        pdf.title("${d.settings.orgName} – ${d.settings.chapterName} Charter")
        pdf.text("Mali özet: $label    |    Hazırlanma tarihi: ${today.format(DATE_FMT)}")

        pdf.section("Kasa bakiyeleri (bugün itibarıyla)")
        val c1 = listOf(Col(40f, 200f), Col(240f, 100f, true), Col(340f, 100f, true), Col(440f, 115f, true))
        pdf.row(listOf("", "Nakit", "Banka", "Toplam"), c1, true)
        for (sc in Scope.entries) {
            val n = Calc.accountBalance(d, sc, Account.NAKIT)
            val b = Calc.accountBalance(d, sc, Account.BANKA)
            pdf.row(listOf(scopeName(d.settings, sc), money(n), money(b), money(n + b)), c1)
        }

        val c2 = listOf(Col(40f, 380f), Col(420f, 135f, true))
        val inc = Calc.categoryTotals(d, true, from, to)
        val exp = Calc.categoryTotals(d, false, from, to)
        pdf.section("Gelirler – $label")
        if (inc.isEmpty()) pdf.text("Kayıt yok.")
        inc.forEach { pdf.row(listOf(it.first, money(it.second)), c2) }
        pdf.row(listOf("Toplam gelir", money(inc.sumOf { it.second })), c2, true)

        pdf.section("Giderler – $label")
        if (exp.isEmpty()) pdf.text("Kayıt yok.")
        exp.forEach { pdf.row(listOf(it.first, money(it.second)), c2) }
        pdf.row(listOf("Toplam gider", money(exp.sumOf { it.second })), c2, true)
        pdf.gap(4f)
        pdf.row(listOf("Dönem sonucu (gelir − gider)", money(inc.sumOf { it.second } - exp.sumOf { it.second })), c2, true)

        pdf.section("Üye aidat durumu (bugün itibarıyla)")
        val c3 = listOf(
            Col(40f, 125f), Col(165f, 85f), Col(250f, 60f, true), Col(310f, 60f, true),
            Col(370f, 60f, true), Col(430f, 60f, true), Col(490f, 65f, true)
        )
        pdf.row(listOf("Üye", "Rütbe", "Aylık", "Geçmiş", "Güncel ay", "Ekstra", "Toplam borç"), c3, true)
        var totalDebt = 0.0
        d.members.sortedBy { it.fullName }.forEach { m ->
            val b = Calc.balance(d, m, today)
            totalDebt += b.total
            pdf.row(
                listOf(m.display(), m.rankLabel(), money(m.monthlyDues), money(b.past), money(b.current), money(b.extra), money(b.total)),
                c3
            )
        }
        pdf.row(listOf("Toplam", "", "", "", "", "", money(totalDebt)), c3, true)

        pdf.section("Kasa hareketleri – $label")
        val c4 = listOf(Col(40f, 58f), Col(98f, 120f), Col(218f, 150f), Col(368f, 60f), Col(428f, 127f, true))
        pdf.row(listOf("Tarih", "Kalem", "Açıklama", "Hesap", "Tutar"), c4, true)
        val entries = d.ledger.filter { Calc.inRange(it, from, to) }.sortedBy { it.date }
        if (entries.isEmpty()) pdf.text("Kayıt yok.")
        entries.forEach { e ->
            pdf.row(
                listOf(fmtDate(e.date), e.category, e.description, e.account.label, (if (e.income) "+" else "-") + money(e.amount)),
                c4
            )
        }

        val f = File(exportDir(ctx), "mali-rapor-${fileLabel(year, month)}.pdf")
        pdf.save(f)
        return f
    }

    fun share(ctx: Context, file: File, mime: String, chooserTitle: String) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, chooserTitle).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
