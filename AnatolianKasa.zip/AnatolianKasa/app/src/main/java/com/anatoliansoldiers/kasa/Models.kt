package com.anatoliansoldiers.kasa

import java.security.MessageDigest
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID

val TR: Locale = Locale("tr", "TR")
val TR_MONTHS = listOf(
    "Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran",
    "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"
)
val TR_MONTHS_SHORT = listOf(
    "Oca", "Şub", "Mar", "Nis", "May", "Haz",
    "Tem", "Ağu", "Eyl", "Eki", "Kas", "Ara"
)
val DATE_FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy")

enum class Rank(val label: String) {
    FULL_PATCH("Full Patch"),
    PROSPECT("Prospect"),
    HANGAROUND("Hangaround"),
    OFFICER("Officer")
}

enum class MemberStatus(val label: String) {
    AKTIF("Aktif"),
    PASIF("Pasif / Dondurulmuş"),
    ONURSAL("Onursal")
}

enum class PayType(val label: String) {
    AIDAT("Aylık aidat"),
    YAMA("Yama (patch) ücreti"),
    CLUBHOUSE("Clubhouse gider payı"),
    ETKINLIK("Etkinlik / parti payı"),
    CEZA("Disiplin cezası"),
    DIGER("Diğer")
}

enum class PayMethod(val label: String) {
    EFT("EFT / Havale"),
    NAKIT("Elden nakit")
}

enum class Account(val label: String) {
    NAKIT("Nakit kasa"),
    BANKA("Banka hesabı")
}

enum class Scope { CHARTER, MERKEZ }

val OFFICER_TITLES = listOf("Başkan", "VP", "Secretary", "Treasurer", "Road Captain", "Sgt. at Arms")

const val CAT_DUES = "Üye aidatları"
const val CAT_FESTIVAL = "Organizasyon / festival geliri"
const val CAT_SUPPORT = "Destekçi (Support) ürün satışı"
const val CAT_PATCH = "Yama ücreti"
const val CAT_CLUBHOUSE_SHARE = "Clubhouse gider payı"
const val CAT_EVENT_SHARE = "Etkinlik / parti payı"
const val CAT_FINE = "Disiplin cezası"
const val CAT_OTHER_INCOME = "Bağış / diğer gelir"
const val CAT_OPENING = "Devir / açılış bakiyesi"
const val CAT_TRANSFER = "Hesaplar arası aktarım"

val INCOME_CATS = listOf(
    CAT_DUES, CAT_FESTIVAL, CAT_SUPPORT, CAT_PATCH, CAT_CLUBHOUSE_SHARE,
    CAT_EVENT_SHARE, CAT_FINE, CAT_OTHER_INCOME, CAT_OPENING, CAT_TRANSFER
)
val EXPENSE_CATS = listOf(
    "Clubhouse kirası", "Clubhouse faturaları", "Etkinlik / konaklama",
    "Yama / yelek üretimi", "Sosyal sorumluluk / yardım",
    "Genel Merkez'e gönderilen", "Diğer gider", CAT_TRANSFER
)
/** Dönem gelir/gider toplamlarına dahil edilmeyen kalemler (sadece bakiyeyi etkiler). */
val NEUTRAL_CATS = setOf(CAT_OPENING, CAT_TRANSFER)

fun PayType.ledgerCategory(): String = when (this) {
    PayType.AIDAT -> CAT_DUES
    PayType.YAMA -> CAT_PATCH
    PayType.CLUBHOUSE -> CAT_CLUBHOUSE_SHARE
    PayType.ETKINLIK -> CAT_EVENT_SHARE
    PayType.CEZA -> CAT_FINE
    PayType.DIGER -> CAT_OTHER_INCOME
}

data class Member(
    val id: String = UUID.randomUUID().toString(),
    val fullName: String,
    val roadName: String = "",
    val phone: String = "",
    val emergency: String = "",
    val chapter: String = "Hatay",
    val rank: Rank = Rank.FULL_PATCH,
    val officerTitle: String = "",
    val status: MemberStatus = MemberStatus.AKTIF,
    /** Pasif/Onursal durumunun başladığı ay (yyyy-MM). Boşsa tüm aylar muaf sayılır. */
    val statusFrom: String = "",
    /** Aidat yükümlülüğünün başladığı ay (yyyy-MM). */
    val startMonth: String,
    val monthlyDues: Double,
    val exemptMonths: Set<String> = emptySet(),
    val pinHash: String = ""
)

data class Payment(
    val id: String = UUID.randomUUID().toString(),
    val memberId: String,
    val date: String,
    val amount: Double,
    val type: PayType,
    val forMonth: String = "",
    val method: PayMethod,
    val receipt: String = "",
    val note: String = "",
    val approved: Boolean,
    val createdBy: String = ""
)

/** Üyeye yazılan ekstra borç (yama, parti payı, ceza vb.). */
data class Charge(
    val id: String = UUID.randomUUID().toString(),
    val memberId: String,
    val date: String,
    val amount: Double,
    val type: PayType,
    val description: String = ""
)

data class LedgerEntry(
    val id: String = UUID.randomUUID().toString(),
    val date: String,
    val amount: Double,
    val income: Boolean,
    val category: String,
    val description: String = "",
    val account: Account,
    val scope: Scope,
    val paymentId: String = ""
)

data class Settings(
    val orgName: String = "Anatolian Soldiers MC",
    val chapterName: String = "Hatay",
    val defaultDues: Double = 0.0,
    val dueDay: Int = 5
)

data class AppData(
    val initialized: Boolean = false,
    val settings: Settings = Settings(),
    val members: List<Member> = emptyList(),
    val payments: List<Payment> = emptyList(),
    val charges: List<Charge> = emptyList(),
    val ledger: List<LedgerEntry> = emptyList()
)

fun Member.display(): String = if (roadName.isBlank()) fullName else "$fullName “$roadName”"

fun Member.rankLabel(): String =
    if (rank == Rank.OFFICER && officerTitle.isNotBlank()) "Officer – $officerTitle" else rank.label

fun scopeName(s: Settings, sc: Scope): String =
    if (sc == Scope.CHARTER) "${s.chapterName} Charter" else "Genel Merkez"

fun money(v: Double): String = String.format(TR, "%,.2f ₺", v)

fun fmtPlain(v: Double): String =
    if (v % 1.0 == 0.0) v.toLong().toString() else String.format(TR, "%.2f", v)

fun ymLabel(ym: YearMonth): String = "${TR_MONTHS[ym.monthValue - 1]} ${ym.year}"

fun ymLabelOf(s: String): String = runCatching { ymLabel(YearMonth.parse(s)) }.getOrDefault(s)

fun fmtDate(iso: String): String =
    runCatching { java.time.LocalDate.parse(iso).format(DATE_FMT) }.getOrDefault(iso)

/** "1500", "1.500", "1.500,50", "1500,5" gibi girişleri sayıya çevirir. */
fun parseAmount(input: String): Double? {
    var s = input.trim().replace("₺", "").replace(" ", "")
    if (s.isEmpty()) return null
    s = when {
        s.contains(',') && s.contains('.') -> s.replace(".", "").replace(',', '.')
        s.contains(',') -> s.replace(',', '.')
        Regex("^\\d{1,3}(\\.\\d{3})+$").matches(s) -> s.replace(".", "")
        else -> s
    }
    return s.toDoubleOrNull()?.takeIf { it >= 0 }
}

fun hashPin(memberId: String, pin: String): String =
    MessageDigest.getInstance("SHA-256")
        .digest("$memberId:$pin".toByteArray())
        .joinToString("") { "%02x".format(it) }
