@file:OptIn(ExperimentalMaterial3Api::class)

package com.anatoliansoldiers.kasa

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.YearMonth

private data class TabDef(val label: String, val icon: ImageVector)

@Composable
fun MainFlow(vm: AppViewModel, d: AppData, me: Member) {
    val admin = Calc.isAdmin(me)
    val tabs = buildList {
        add(TabDef("Özet", Icons.Default.Home))
        if (admin) add(TabDef("Üyeler", Icons.Default.People)) else add(TabDef("Aidatım", Icons.Default.Person))
        add(TabDef("Kasa", Icons.Default.AccountBalance))
        if (admin) add(TabDef("Rapor", Icons.Default.Assessment))
    }
    val top = vm.stack.lastOrNull()
    BackHandler(enabled = top != null) { vm.pop() }

    if (top != null) {
        when (top) {
            is Screen.MemberDetail -> MemberDetailScreen(vm, d, me, top.id)
            is Screen.MemberEdit -> MemberEditScreen(vm, d, top.id)
            is Screen.PaymentAdd -> PaymentAddScreen(vm, d, me, top.memberId, top.month)
            is Screen.ChargeAdd -> ChargeAddScreen(vm, d, top.memberId)
            is Screen.LedgerAdd -> LedgerAddScreen(vm, d, top.income)
            Screen.Approvals -> ApprovalsScreen(vm, d)
            Screen.SettingsPage -> SettingsScreen(vm, d, me)
        }
        return
    }

    val idx = vm.tab.coerceIn(0, tabs.lastIndex)
    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = idx == i,
                        onClick = { vm.tab = i },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label) }
                    )
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            when (tabs[idx].label) {
                "Özet" -> HomeScreen(vm, d, me)
                "Üyeler" -> MembersScreen(vm, d)
                "Aidatım" -> MemberBody(vm, d, me, me, readOnly = true)
                "Kasa" -> LedgerScreen(vm, d, admin)
                "Rapor" -> ReportScreen(d)
            }
        }
    }
}

@Composable
fun HomeScreen(vm: AppViewModel, d: AppData, me: Member) {
    val admin = Calc.isAdmin(me)
    val today = LocalDate.now()
    val pending = d.payments.count { !it.approved }
    val nakit = Calc.accountBalance(d, Scope.CHARTER, Account.NAKIT)
    val banka = Calc.accountBalance(d, Scope.CHARTER, Account.BANKA)
    AskNotificationPermission()

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text(d.settings.orgName.uppercase(), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text("${d.settings.chapterName} Charter Kasası", style = MaterialTheme.typography.titleLarge)
                    Text("${me.display()} · ${me.rankLabel()}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                OutlinedButton(onClick = { vm.push(Screen.SettingsPage) }) { Text("Ayarlar") }
            }
        }
        item {
            KasaCard {
                Text("${d.settings.chapterName} Charter kasası", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(money(nakit + banka), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = balanceColor(nakit + banka).takeIf { it != androidx.compose.ui.graphics.Color.Unspecified } ?: MaterialTheme.colorScheme.onSurface)
                KV("Nakit kasa", money(nakit))
                KV("Banka hesabı", money(banka))
            }
        }
        if (admin) {
            val late = d.members.filter { it.status == MemberStatus.AKTIF && Calc.overdueAmount(d, it, today) > 0.005 }
            item {
                KasaCard(onClick = if (pending > 0) ({ vm.push(Screen.Approvals) }) else null) {
                    KV("Onay bekleyen ödeme", pending.toString(), bold = true)
                    KV("Geciken aidatı olan üye", late.size.toString(), if (late.isNotEmpty()) Red else androidx.compose.ui.graphics.Color.Unspecified, true)
                    KV("Geciken toplam tutar", money(late.sumOf { Calc.overdueAmount(d, it, today) }))
                    if (pending > 0) Text("Onaylamak için dokunun →", color = MaterialTheme.colorScheme.primary)
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.push(Screen.PaymentAdd(null)) }, modifier = Modifier.weight(1f)) { Text("Ödeme gir") }
                    OutlinedButton(onClick = { vm.push(Screen.LedgerAdd(false)) }, modifier = Modifier.weight(1f)) { Text("Gider ekle") }
                }
            }
        } else {
            val b = Calc.balance(d, me, today)
            item {
                KasaCard(onClick = { vm.tab = 1 }) {
                    Text("Aidat durumum", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        if (b.total > 0.005) "Toplam borç: ${money(b.total)}" else "Borcunuz yok",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = if (b.total > 0.005) Red else Green
                    )
                    if (b.credit > 0.005) Text("Alacağınız: ${money(b.credit)}", color = Green)
                    Text("Ayrıntı için dokunun →", color = MaterialTheme.colorScheme.primary)
                }
            }
            item {
                Button(onClick = { vm.push(Screen.PaymentAdd(me.id)) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Ödeme bildir (dekont yükle)")
                }
            }
        }
        item {
            Title("Son kasa hareketleri")
        }
        val recent = d.ledger.filter { it.scope == Scope.CHARTER }.sortedByDescending { it.date }.take(6)
        if (recent.isEmpty()) item { Text("Henüz kayıt yok.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(recent, key = { it.id }) { LedgerRow(it) }
        item { androidx.compose.foundation.layout.Spacer(Modifier.padding(8.dp)) }
    }
}

@Composable
fun LedgerRow(e: LedgerEntry) {
    KasaCard {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(e.category, fontWeight = FontWeight.Medium)
                if (e.description.isNotBlank()) Text(e.description, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                Text("${fmtDate(e.date)} · ${e.account.label}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
            Text(
                (if (e.income) "+" else "−") + money(e.amount),
                color = if (e.income) Green else Red,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun MembersScreen(vm: AppViewModel, d: AppData) {
    val today = LocalDate.now()
    val year = today.year
    var query by remember { mutableStateOf("") }
    val list = d.members.sortedBy { it.fullName }.filter {
        query.isBlank() || it.fullName.contains(query, true) || it.roadName.contains(query, true)
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Üyeler (${d.members.size})", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Button(onClick = { vm.push(Screen.MemberEdit(null)) }) { Text("Üye ekle") }
        }
        FormField("Ara (ad / yol adı)", query) { query = it }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            items(list, key = { it.id }) { m ->
                val b = Calc.balance(d, m, today)
                KasaCard(onClick = { vm.push(Screen.MemberDetail(m.id)) }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(m.display(), fontWeight = FontWeight.Bold)
                            Text("${m.rankLabel()} · ${m.chapter} · ${m.status.label}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(
                            if (b.total > 0.005) money(b.total) else "Borç yok",
                            color = if (b.total > 0.005) Red else Green,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    androidx.compose.foundation.layout.Spacer(Modifier.padding(3.dp))
                    MonthStrip((1..12).map { Calc.monthState(d, m, YearMonth.of(year, it), today) })
                }
            }
            item { androidx.compose.foundation.layout.Spacer(Modifier.padding(8.dp)) }
        }
    }
}
