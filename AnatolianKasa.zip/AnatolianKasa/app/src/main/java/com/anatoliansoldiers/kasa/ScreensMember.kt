@file:OptIn(ExperimentalMaterial3Api::class)

package com.anatoliansoldiers.kasa

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.YearMonth

@Composable
fun MemberDetailScreen(vm: AppViewModel, d: AppData, me: Member, id: String) {
    val m = d.members.firstOrNull { it.id == id }
    if (m == null) {
        LaunchedEffect(Unit) { vm.pop() }
        return
    }
    Page(m.display(), onBack = { vm.pop() }) {
        MemberBody(vm, d, me, m, readOnly = !Calc.isAdmin(me))
    }
}

@Composable
fun MemberBody(vm: AppViewModel, d: AppData, viewer: Member, m: Member, readOnly: Boolean) {
    val today = LocalDate.now()
    var year by remember { mutableStateOf(today.year) }
    var receipt by remember { mutableStateOf<String?>(null) }
    var monthDialog by remember { mutableStateOf<YearMonth?>(null) }
    var delPayment by remember { mutableStateOf<String?>(null) }
    var delCharge by remember { mutableStateOf<String?>(null) }

    val b = Calc.balance(d, m, today)
    val pays = d.payments.filter { it.memberId == m.id }.sortedByDescending { it.date }
    val charges = d.charges.filter { it.memberId == m.id }.sortedByDescending { it.date }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Spacer(Modifier.height(6.dp)) }
        item {
            KasaCard {
                Text(m.display(), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                KV("Rütbe", m.rankLabel())
                KV("Chapter", m.chapter)
                KV("Durum", m.status.label)
                if (m.phone.isNotBlank()) KV("Telefon", m.phone)
                if (m.emergency.isNotBlank()) KV("Acil durum", m.emergency)
                KV("Aylık aidat", money(m.monthlyDues))
                KV("Aidat başlangıcı", ymLabelOf(m.startMonth))
            }
        }
        item {
            if (readOnly) {
                Button(
                    onClick = { vm.push(Screen.PaymentAdd(m.id)) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Ödeme bildir (dekont yükle)") }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.push(Screen.PaymentAdd(m.id)) }, modifier = Modifier.weight(1f)) { Text("Ödeme gir") }
                    OutlinedButton(onClick = { vm.push(Screen.ChargeAdd(m.id)) }, modifier = Modifier.weight(1f)) { Text("Ekstra borç") }
                    OutlinedButton(onClick = { vm.push(Screen.MemberEdit(m.id)) }, modifier = Modifier.weight(1f)) { Text("Düzenle") }
                }
            }
        }
        item {
            KasaCard {
                Text("Bakiye özeti", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                KV("Geçmiş dönem borcu", money(b.past), if (b.past > 0.005) Red else Color.Unspecified)
                KV("Güncel ay borcu", money(b.current), if (b.current > 0.005) Red else Color.Unspecified)
                KV("Ekstra borç (yama, pay, ceza)", money(b.extra), if (b.extra > 0.005) Red else Color.Unspecified)
                KV("Peşin ödenen / alacak", money(b.credit), if (b.credit > 0.005) Green else Color.Unspecified)
                KV("Toplam borç", money(b.total), if (b.total > 0.005) Red else Green, bold = true)
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = { year-- }) { Text("‹ ${year - 1}") }
                Text("$year aidat takvimi", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                TextButton(onClick = { year++ }) { Text("${year + 1} ›") }
            }
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                for (row in 0 until 4) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (col in 0 until 3) {
                            val mo = row * 3 + col + 1
                            val ym = YearMonth.of(year, mo)
                            MonthTile(
                                TR_MONTHS_SHORT[mo - 1],
                                Calc.monthState(d, m, ym, today),
                                Modifier.weight(1f)
                            ) { if (!readOnly) monthDialog = ym }
                        }
                    }
                }
            }
            Text(
                "Yeşil: ödendi · Kırmızı: gecikmede · Sarı: bekliyor · Gri: muaf",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
        item { Title("Ekstra katkı payları / borçlar") }
        if (charges.isEmpty()) item { Text("Kayıt yok.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(charges, key = { it.id }) { c ->
            KasaCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(c.type.label, fontWeight = FontWeight.Medium)
                        if (c.description.isNotBlank()) Text(c.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(fmtDate(c.date), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(money(c.amount), fontWeight = FontWeight.Bold)
                }
                if (!readOnly) TextButton(onClick = { delCharge = c.id }) { Text("Sil") }
            }
        }
        item { Title("Ödeme geçmişi") }
        if (pays.isEmpty()) item { Text("Henüz ödeme yok.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(pays, key = { it.id }) { p ->
            KasaCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (p.type == PayType.AIDAT) "Aidat – ${ymLabelOf(p.forMonth)}" else p.type.label,
                            fontWeight = FontWeight.Medium
                        )
                        Text("${fmtDate(p.date)} · ${p.method.label}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (p.note.isNotBlank()) Text(p.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                        Text(money(p.amount), fontWeight = FontWeight.Bold)
                        if (p.approved) Pill("Onaylandı", Green) else Pill("Onay bekliyor", Amber)
                    }
                }
                Row {
                    if (p.receipt.isNotBlank()) TextButton(onClick = { receipt = p.receipt }) { Text("Dekontu gör") }
                    if (!readOnly) TextButton(onClick = { delPayment = p.id }) { Text("Sil") }
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }

    receipt?.let { ReceiptDialog(it) { receipt = null } }

    monthDialog?.let { ym ->
        val exempt = m.exemptMonths.contains(ym.toString())
        AlertDialog(
            onDismissRequest = { monthDialog = null },
            title = { Text(ymLabel(ym)) },
            text = { Text("Durum: ${stateLabel(Calc.monthState(d, m, ym, today))}") },
            confirmButton = {
                TextButton(onClick = { monthDialog = null; vm.push(Screen.PaymentAdd(m.id, ym.toString())) }) { Text("Ödeme gir") }
            },
            dismissButton = {
                TextButton(onClick = { vm.toggleExempt(m.id, ym); monthDialog = null }) {
                    Text(if (exempt) "Muafiyeti kaldır" else "Muaf yap")
                }
            }
        )
    }
    delPayment?.let { id ->
        ConfirmDialog(
            "Ödeme silinsin mi?",
            "Ödeme ve bağlı kasa kaydı birlikte silinir. Bu işlem geri alınamaz.",
            "Sil", { vm.deletePayment(id); delPayment = null }, { delPayment = null }
        )
    }
    delCharge?.let { id ->
        ConfirmDialog(
            "Ekstra borç silinsin mi?", "Bu işlem geri alınamaz.",
            "Sil", { vm.deleteCharge(id); delCharge = null }, { delCharge = null }
        )
    }
}

@Composable
fun MemberEditScreen(vm: AppViewModel, d: AppData, id: String?) {
    val old = d.members.firstOrNull { it.id == id }
    var name by remember { mutableStateOf(old?.fullName ?: "") }
    var road by remember { mutableStateOf(old?.roadName ?: "") }
    var phone by remember { mutableStateOf(old?.phone ?: "") }
    var emergency by remember { mutableStateOf(old?.emergency ?: "") }
    var chapter by remember { mutableStateOf(old?.chapter ?: d.settings.chapterName) }
    var rank by remember { mutableStateOf(old?.rank ?: Rank.FULL_PATCH) }
    var title by remember { mutableStateOf(old?.officerTitle?.ifBlank { null } ?: OFFICER_TITLES[0]) }
    var status by remember { mutableStateOf(old?.status ?: MemberStatus.AKTIF) }
    var start by remember { mutableStateOf(old?.startMonth ?: YearMonth.now().toString()) }
    var dues by remember { mutableStateOf(fmtPlain(old?.monthlyDues ?: d.settings.defaultDues)) }
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    val startOptions = remember {
        val now = YearMonth.now()
        (0..47).map { now.minusMonths(it.toLong()) }
    }

    Page(if (old == null) "Yeni üye" else "Üyeyi düzenle", onBack = { vm.pop() }) {
        FormColumn {
            FormField("Ad Soyad", name) { name = it }
            FormField("Road Name (Yol Adı / Lakap)", road) { road = it }
            FormField("Telefon", phone, androidx.compose.ui.text.input.KeyboardType.Phone) { phone = it }
            FormField("Acil durum iletişim (ad / telefon)", emergency) { emergency = it }
            FormField("Chapter (Şube)", chapter) { chapter = it }
            PickerField("Rütbe", rank.label, Rank.entries.map { it.label to it }) { rank = it }
            if (rank == Rank.OFFICER) {
                PickerField("Officer görevi", title, OFFICER_TITLES.map { it to it }) { title = it }
            }
            PickerField("Üyelik durumu", status.label, MemberStatus.entries.map { it.label to it }) { status = it }
            PickerField(
                "Aidat başlangıç ayı", ymLabelOf(start),
                startOptions.map { ymLabel(it) to it.toString() }
            ) { start = it }
            AmountField("Aylık aidat (₺)", dues) { dues = it }
            PinField(if (old == null) "Giriş PIN'i (4-6 rakam)" else "Yeni PIN (değiştirmek için)", pin) { pin = it }
            if (status != MemberStatus.AKTIF) {
                Text(
                    "Pasif / onursal üyelerin aidatı, durumun değiştiği aydan itibaren muaf sayılır.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(
                onClick = {
                    val amount = parseAmount(dues)
                    when {
                        name.isBlank() -> error = "Ad Soyad gerekli."
                        amount == null -> error = "Aidat tutarı geçersiz."
                        old == null && pin.length < 4 -> error = "Yeni üye için en az 4 rakamlı PIN gerekli."
                        pin.isNotEmpty() && pin.length < 4 -> error = "PIN en az 4 rakam olmalı."
                        else -> {
                            val m = Member(
                                id = old?.id ?: java.util.UUID.randomUUID().toString(),
                                fullName = name.trim(), roadName = road.trim(), phone = phone.trim(),
                                emergency = emergency.trim(), chapter = chapter.trim().ifBlank { d.settings.chapterName },
                                rank = rank, officerTitle = if (rank == Rank.OFFICER) title else "",
                                status = status, statusFrom = old?.statusFrom ?: "",
                                startMonth = start, monthlyDues = amount,
                                exemptMonths = old?.exemptMonths ?: emptySet()
                            )
                            if (vm.saveMember(m, pin)) vm.pop()
                            else error = "En az bir aktif Başkan veya Treasurer kalmalı."
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Kaydet") }
        }
    }
}
