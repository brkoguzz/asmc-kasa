package com.anatoliansoldiers.kasa

import java.time.LocalDate
import java.time.YearMonth

enum class MonthState { PAID, OVERDUE, DUE, FUTURE, EXEMPT, NA }

data class Balance(val past: Double, val current: Double, val credit: Double, val extra: Double) {
    val total: Double get() = past + current + extra
}

object Calc {
    private val adminTitles = setOf("Başkan", "Treasurer")

    fun isAdmin(m: Member?): Boolean =
        m != null && m.rank == Rank.OFFICER && m.officerTitle in adminTitles

    fun startOf(m: Member): YearMonth =
        runCatching { YearMonth.parse(m.startMonth) }.getOrDefault(YearMonth.of(2000, 1))

    fun isExempt(m: Member, ym: YearMonth): Boolean {
        if (m.exemptMonths.contains(ym.toString())) return true
        if (m.status == MemberStatus.AKTIF) return false
        val from = runCatching { YearMonth.parse(m.statusFrom) }.getOrNull() ?: return true
        return !ym.isBefore(from)
    }

    fun duesPaid(d: AppData, memberId: String, ym: YearMonth): Double =
        d.payments
            .filter { it.approved && it.memberId == memberId && it.type == PayType.AIDAT && it.forMonth == ym.toString() }
            .sumOf { it.amount }

    fun monthState(d: AppData, m: Member, ym: YearMonth, today: LocalDate = LocalDate.now()): MonthState {
        if (ym.isBefore(startOf(m))) return MonthState.NA
        if (isExempt(m, ym)) return MonthState.EXEMPT
        if (duesPaid(d, m.id, ym) >= m.monthlyDues - 0.005) return MonthState.PAID
        val cur = YearMonth.from(today)
        return when {
            ym.isBefore(cur) -> MonthState.OVERDUE
            ym == cur -> if (today.dayOfMonth > d.settings.dueDay) MonthState.OVERDUE else MonthState.DUE
            else -> MonthState.FUTURE
        }
    }

    fun balance(d: AppData, m: Member, today: LocalDate = LocalDate.now()): Balance {
        val start = startOf(m)
        val cur = YearMonth.from(today)
        val byMonth = d.payments
            .filter { it.approved && it.memberId == m.id && it.type == PayType.AIDAT }
            .groupBy { it.forMonth }
            .mapValues { e -> e.value.sumOf { it.amount } }

        var past = 0.0
        var current = 0.0
        var credit = 0.0

        for ((key, paid) in byMonth) {
            val pm = runCatching { YearMonth.parse(key) }.getOrNull()
            if (pm == null || pm.isBefore(start) || pm.isAfter(cur) || isExempt(m, pm)) {
                credit += paid
            } else if (paid > m.monthlyDues) {
                credit += paid - m.monthlyDues
            }
        }

        var ym = start
        while (!ym.isAfter(cur)) {
            if (!isExempt(m, ym)) {
                val short = m.monthlyDues - (byMonth[ym.toString()] ?: 0.0)
                if (short > 0.005) {
                    if (ym == cur) current += short else past += short
                }
            }
            ym = ym.plusMonths(1)
        }

        val charged = d.charges.filter { it.memberId == m.id }.sumOf { it.amount }
        val extraPaid = d.payments
            .filter { it.approved && it.memberId == m.id && it.type != PayType.AIDAT }
            .sumOf { it.amount }
        return Balance(past, current, credit, maxOf(0.0, charged - extraPaid))
    }

    /** Vadesi geçmiş tutar: geçmiş aylar + (son ödeme günü geçtiyse) bu ay. Ekstra borç dahil değil. */
    fun overdueAmount(d: AppData, m: Member, today: LocalDate = LocalDate.now()): Double {
        val b = balance(d, m, today)
        val late = today.dayOfMonth > d.settings.dueDay
        return b.past + if (late) b.current else 0.0
    }

    fun accountBalance(d: AppData, scope: Scope?, account: Account): Double =
        d.ledger
            .filter { (scope == null || it.scope == scope) && it.account == account }
            .sumOf { if (it.income) it.amount else -it.amount }

    fun inRange(e: LedgerEntry, from: LocalDate, to: LocalDate): Boolean {
        val dt = runCatching { LocalDate.parse(e.date) }.getOrNull() ?: return false
        return !dt.isBefore(from) && !dt.isAfter(to)
    }

    fun categoryTotals(d: AppData, income: Boolean, from: LocalDate, to: LocalDate): List<Pair<String, Double>> =
        d.ledger
            .filter { it.income == income && it.category !in NEUTRAL_CATS && inRange(it, from, to) }
            .groupBy { it.category }
            .map { it.key to it.value.sumOf { e -> e.amount } }
            .sortedByDescending { it.second }
}
