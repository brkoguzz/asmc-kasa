package com.anatoliansoldiers.kasa

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate
import java.time.YearMonth
import java.util.UUID

sealed interface Screen {
    data class MemberDetail(val id: String) : Screen
    data class MemberEdit(val id: String?) : Screen
    data class PaymentAdd(val memberId: String?, val month: String? = null) : Screen
    data class ChargeAdd(val memberId: String) : Screen
    data class LedgerAdd(val income: Boolean) : Screen
    data object Approvals : Screen
    data object SettingsPage : Screen
}

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val appCtx: Application = app
    private val repo = Repository(app)
    private val prefs = app.getSharedPreferences("session", Context.MODE_PRIVATE)

    private val _data = MutableStateFlow(repo.load())
    val data: StateFlow<AppData> = _data.asStateFlow()

    private val _meId = MutableStateFlow(prefs.getString("memberId", null))
    val meId: StateFlow<String?> = _meId.asStateFlow()

    val stack = mutableStateListOf<Screen>()
    var tab by mutableStateOf(0)

    private fun mutate(f: (AppData) -> AppData) {
        val n = f(_data.value)
        _data.value = n
        repo.save(n)
    }

    // ---- gezinme ----
    fun push(s: Screen) { stack.add(s) }
    fun pop() { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) }

    // ---- oturum ----
    fun login(memberId: String, pin: String): Boolean {
        val m = _data.value.members.firstOrNull { it.id == memberId } ?: return false
        if (m.pinHash != hashPin(m.id, pin)) return false
        prefs.edit().putString("memberId", m.id).apply()
        _meId.value = m.id
        stack.clear()
        tab = 0
        return true
    }

    fun logout() {
        prefs.edit().remove("memberId").apply()
        _meId.value = null
        stack.clear()
        tab = 0
    }

    fun setup(org: String, chapter: String, dues: Double, dueDay: Int, name: String, road: String, pin: String) {
        val id = UUID.randomUUID().toString()
        val admin = Member(
            id = id, fullName = name, roadName = road, chapter = chapter,
            rank = Rank.OFFICER, officerTitle = "Treasurer",
            startMonth = YearMonth.now().toString(), monthlyDues = dues,
            pinHash = hashPin(id, pin)
        )
        mutate {
            AppData(
                initialized = true,
                settings = Settings(org.ifBlank { "Anatolian Soldiers MC" }, chapter.ifBlank { "Hatay" }, dues, dueDay),
                members = listOf(admin)
            )
        }
        prefs.edit().putString("memberId", id).apply()
        _meId.value = id
    }

    fun updateSettings(s: Settings) = mutate { it.copy(settings = s) }

    // ---- üyeler ----
    fun saveMember(m: Member, newPin: String): Boolean {
        val d = _data.value
        val old = d.members.firstOrNull { it.id == m.id }
        var mm = m
        mm = when {
            newPin.isNotBlank() -> mm.copy(pinHash = hashPin(mm.id, newPin))
            old != null -> mm.copy(pinHash = old.pinHash)
            else -> mm
        }
        if (old == null || old.status != mm.status) {
            mm = mm.copy(statusFrom = if (mm.status == MemberStatus.AKTIF) "" else YearMonth.now().toString())
        }
        val after = if (old == null) d.members + mm else d.members.map { if (it.id == mm.id) mm else it }
        if (after.none { Calc.isAdmin(it) && it.status == MemberStatus.AKTIF }) return false
        mutate { it.copy(members = after) }
        return true
    }

    fun toggleExempt(memberId: String, ym: YearMonth) = mutate { d ->
        val key = ym.toString()
        d.copy(members = d.members.map {
            if (it.id == memberId) {
                it.copy(exemptMonths = if (key in it.exemptMonths) it.exemptMonths - key else it.exemptMonths + key)
            } else it
        })
    }

    // ---- ödemeler ----
    private fun ledgerFor(d: AppData, p: Payment): LedgerEntry {
        val who = d.members.firstOrNull { it.id == p.memberId }?.display() ?: "Üye"
        val what = if (p.type == PayType.AIDAT) "Aidat ${ymLabelOf(p.forMonth)}" else p.type.label
        return LedgerEntry(
            date = p.date, amount = p.amount, income = true,
            category = p.type.ledgerCategory(), description = "$who – $what",
            account = if (p.method == PayMethod.NAKIT) Account.NAKIT else Account.BANKA,
            scope = Scope.CHARTER, paymentId = p.id
        )
    }

    private fun copyReceipt(uri: Uri): String {
        val name = UUID.randomUUID().toString() + ".jpg"
        appCtx.contentResolver.openInputStream(uri)?.use { input ->
            File(repo.receiptsDir, name).outputStream().use { out -> input.copyTo(out) }
        }
        return name
    }

    fun addPayment(p: Payment, receiptUri: Uri?, onDone: () -> Unit) {
        viewModelScope.launch {
            val name = if (receiptUri != null) {
                withContext(Dispatchers.IO) { runCatching { copyReceipt(receiptUri) }.getOrDefault("") }
            } else ""
            val pay = p.copy(receipt = name)
            mutate { d ->
                d.copy(
                    payments = d.payments + pay,
                    ledger = if (pay.approved) d.ledger + ledgerFor(d, pay) else d.ledger
                )
            }
            onDone()
        }
    }

    fun approve(id: String) = mutate { d ->
        val p = d.payments.firstOrNull { it.id == id && !it.approved } ?: return@mutate d
        d.copy(
            payments = d.payments.map { if (it.id == id) it.copy(approved = true) else it },
            ledger = d.ledger + ledgerFor(d, p)
        )
    }

    fun reject(id: String) = deletePayment(id)

    fun deletePayment(id: String) {
        val p = _data.value.payments.firstOrNull { it.id == id } ?: return
        if (p.receipt.isNotBlank()) File(repo.receiptsDir, p.receipt).delete()
        mutate { d ->
            d.copy(
                payments = d.payments.filter { it.id != id },
                ledger = d.ledger.filter { it.paymentId != id }
            )
        }
    }

    // ---- ekstra borçlar ----
    fun addCharge(c: Charge) = mutate { it.copy(charges = it.charges + c) }
    fun deleteCharge(id: String) = mutate { it.copy(charges = it.charges.filter { c -> c.id != id }) }

    // ---- kasa ----
    fun addLedger(e: LedgerEntry) = mutate { it.copy(ledger = it.ledger + e) }
    fun deleteLedger(id: String) = mutate { it.copy(ledger = it.ledger.filter { e -> e.id != id }) }

    // ---- yedek ----
    fun backupFile(): File {
        val f = File(Export.exportDir(appCtx), "kasa-yedek-${LocalDate.now()}.json")
        f.writeText(Json.encode(_data.value))
        return f
    }

    fun importBackup(text: String): Boolean {
        val d = try { Json.decode(text) } catch (e: Exception) { return false }
        if (d.members.none { Calc.isAdmin(it) }) return false
        mutate { d.copy(initialized = true) }
        if (_data.value.members.none { it.id == _meId.value }) logout()
        return true
    }
}
