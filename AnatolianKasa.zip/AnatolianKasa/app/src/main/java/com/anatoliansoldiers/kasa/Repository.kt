package com.anatoliansoldiers.kasa

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object Json {
    private inline fun <reified T : Enum<T>> enumOf(name: String?, default: T): T =
        enumValues<T>().firstOrNull { it.name == name } ?: default

    private fun <T> JSONArray?.mapObjects(f: (JSONObject) -> T): List<T> {
        if (this == null) return emptyList()
        return (0 until length()).map { f(getJSONObject(it)) }
    }

    fun encode(d: AppData): String = JSONObject().apply {
        put("version", 1)
        put("initialized", d.initialized)
        put("settings", JSONObject().apply {
            put("orgName", d.settings.orgName)
            put("chapterName", d.settings.chapterName)
            put("defaultDues", d.settings.defaultDues)
            put("dueDay", d.settings.dueDay)
        })
        put("members", JSONArray().apply { d.members.forEach { put(memberJson(it)) } })
        put("payments", JSONArray().apply { d.payments.forEach { put(paymentJson(it)) } })
        put("charges", JSONArray().apply { d.charges.forEach { put(chargeJson(it)) } })
        put("ledger", JSONArray().apply { d.ledger.forEach { put(ledgerJson(it)) } })
    }.toString()

    fun decode(text: String): AppData {
        val o = JSONObject(text)
        val s = o.optJSONObject("settings") ?: JSONObject()
        return AppData(
            initialized = o.optBoolean("initialized", true),
            settings = Settings(
                orgName = s.optString("orgName", "Anatolian Soldiers MC"),
                chapterName = s.optString("chapterName", "Hatay"),
                defaultDues = s.optDouble("defaultDues", 0.0),
                dueDay = s.optInt("dueDay", 5)
            ),
            members = o.optJSONArray("members").mapObjects { memberFrom(it) },
            payments = o.optJSONArray("payments").mapObjects { paymentFrom(it) },
            charges = o.optJSONArray("charges").mapObjects { chargeFrom(it) },
            ledger = o.optJSONArray("ledger").mapObjects { ledgerFrom(it) }
        )
    }

    private fun memberJson(m: Member) = JSONObject().apply {
        put("id", m.id)
        put("fullName", m.fullName)
        put("roadName", m.roadName)
        put("phone", m.phone)
        put("emergency", m.emergency)
        put("chapter", m.chapter)
        put("rank", m.rank.name)
        put("officerTitle", m.officerTitle)
        put("status", m.status.name)
        put("statusFrom", m.statusFrom)
        put("startMonth", m.startMonth)
        put("monthlyDues", m.monthlyDues)
        put("exemptMonths", JSONArray().apply { m.exemptMonths.forEach { put(it) } })
        put("pinHash", m.pinHash)
    }

    private fun memberFrom(o: JSONObject): Member {
        val ex = o.optJSONArray("exemptMonths")
        val exempt = if (ex == null) emptySet() else (0 until ex.length()).map { ex.getString(it) }.toSet()
        return Member(
            id = o.getString("id"),
            fullName = o.optString("fullName"),
            roadName = o.optString("roadName"),
            phone = o.optString("phone"),
            emergency = o.optString("emergency"),
            chapter = o.optString("chapter", "Hatay"),
            rank = enumOf(o.optString("rank"), Rank.FULL_PATCH),
            officerTitle = o.optString("officerTitle"),
            status = enumOf(o.optString("status"), MemberStatus.AKTIF),
            statusFrom = o.optString("statusFrom"),
            startMonth = o.optString("startMonth"),
            monthlyDues = o.optDouble("monthlyDues", 0.0),
            exemptMonths = exempt,
            pinHash = o.optString("pinHash")
        )
    }

    private fun paymentJson(p: Payment) = JSONObject().apply {
        put("id", p.id)
        put("memberId", p.memberId)
        put("date", p.date)
        put("amount", p.amount)
        put("type", p.type.name)
        put("forMonth", p.forMonth)
        put("method", p.method.name)
        put("receipt", p.receipt)
        put("note", p.note)
        put("approved", p.approved)
        put("createdBy", p.createdBy)
    }

    private fun paymentFrom(o: JSONObject) = Payment(
        id = o.getString("id"),
        memberId = o.optString("memberId"),
        date = o.optString("date"),
        amount = o.optDouble("amount", 0.0),
        type = enumOf(o.optString("type"), PayType.AIDAT),
        forMonth = o.optString("forMonth"),
        method = enumOf(o.optString("method"), PayMethod.EFT),
        receipt = o.optString("receipt"),
        note = o.optString("note"),
        approved = o.optBoolean("approved", true),
        createdBy = o.optString("createdBy")
    )

    private fun chargeJson(c: Charge) = JSONObject().apply {
        put("id", c.id)
        put("memberId", c.memberId)
        put("date", c.date)
        put("amount", c.amount)
        put("type", c.type.name)
        put("description", c.description)
    }

    private fun chargeFrom(o: JSONObject) = Charge(
        id = o.getString("id"),
        memberId = o.optString("memberId"),
        date = o.optString("date"),
        amount = o.optDouble("amount", 0.0),
        type = enumOf(o.optString("type"), PayType.DIGER),
        description = o.optString("description")
    )

    private fun ledgerJson(e: LedgerEntry) = JSONObject().apply {
        put("id", e.id)
        put("date", e.date)
        put("amount", e.amount)
        put("income", e.income)
        put("category", e.category)
        put("description", e.description)
        put("account", e.account.name)
        put("scope", e.scope.name)
        put("paymentId", e.paymentId)
    }

    private fun ledgerFrom(o: JSONObject) = LedgerEntry(
        id = o.getString("id"),
        date = o.optString("date"),
        amount = o.optDouble("amount", 0.0),
        income = o.optBoolean("income", true),
        category = o.optString("category"),
        description = o.optString("description"),
        account = enumOf(o.optString("account"), Account.NAKIT),
        scope = enumOf(o.optString("scope"), Scope.CHARTER),
        paymentId = o.optString("paymentId")
    )
}

class Repository(private val context: Context) {
    private val file = File(context.filesDir, "kasa.json")
    val receiptsDir: File = File(context.filesDir, "receipts").also { it.mkdirs() }

    fun load(): AppData {
        if (!file.exists()) return AppData()
        return try {
            Json.decode(file.readText())
        } catch (e: Exception) {
            // Bozuk dosyayı silmeden yedekle, boş veriyle devam et.
            file.renameTo(File(context.filesDir, "kasa-bozuk-${System.currentTimeMillis()}.json"))
            AppData()
        }
    }

    fun save(d: AppData) {
        val tmp = File(context.filesDir, "kasa.json.tmp")
        tmp.writeText(Json.encode(d))
        if (!tmp.renameTo(file)) {
            file.writeText(tmp.readText())
            tmp.delete()
        }
    }
}
