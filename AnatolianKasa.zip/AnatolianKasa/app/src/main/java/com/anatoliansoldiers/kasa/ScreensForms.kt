@file:OptIn(ExperimentalMaterial3Api::class)

package com.anatoliansoldiers.kasa

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.YearMonth

@Composable
fun PaymentAddScreen(vm: AppViewModel, d: AppData, me: Member, memberId: String?, month: String?) {
    val admin = Calc.isAdmin(me)
    var sel by remember { mutableStateOf(if (admin) memberId else me.id) }
    val member = d.members.firstOrNull { it.id == sel }
    var type by remember { mutableStateOf(PayType.AIDAT) }
    var ym by remember { mutableStateOf(month ?: YearMonth.now().toString()) }
    var amount by remember { mutableStateOf(member?.let { fmtPlain(it.monthlyDues) } ?: "") }
    var method by remember { mutableStateOf(PayMethod.EFT) }
    var date by remember { mutableStateOf(LocalDate.now()) }
    var note by remember { mutableStateOf("") }
    var receiptUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) receiptUri = uri
    }
    val monthOptions = remember(month) {
        val now = YearMonth.now()
        val base = (-11..3).map { now.plusMonths(it.toLong()) }.toMutableList()
        month?.let { runCatching { YearMonth.parse(it) }.getOrNull() }?.let { if (it !in base) base.add(it) }
        base.sorted().reversed()
    }

    Page(if (admin) "Ödeme gir" else "Ödeme bildir", onBack = { vm.pop() }) {
        FormColumn {
            if (admin) {
                PickerField(
                    "Üye", member?.display() ?: "Seçiniz",
                    d.members.sortedBy { it.fullName }.map { it.display() to it.id }
                ) { id ->
                    sel = id
                    if (type == PayType.AIDAT) d.members.firstOrNull { it.id == id }?.let { amount = fmtPlain(it.monthlyDues) }
                }
            } else {
                KV("Üye", me.display())
            }
            PickerField("Ödeme türü", type.label, PayType.entries.map { it.label to it }) {
                type = it
                if (it == PayType.AIDAT && member != null) amount = fmtPlain(member.monthlyDues)
            }
            if (type == PayType.AIDAT) {
                PickerField("Hangi ayın aidatı", ymLabelOf(ym), monthOptions.map { ymLabel(it) to it.toString() }) { ym = it }
            }
            AmountField("Tutar (₺)", amount) { amount = it }
            PickerField("Ödeme yöntemi", method.label, PayMethod.entries.map { it.label to it }) { method = it }
            DateField("Ödeme tarihi", date) { date = it }
            FormField("Not (isteğe bağlı)", note) { note = it }
            OutlinedButton(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                Text(if (receiptUri == null) "Dekont fotoğrafı ekle" else "Dekontu değiştir")
            }
            receiptUri?.let { UriImage(it, Modifier.fillMaxWidth().height(180.dp)) }
            if (!admin) {
                Text(
                    "Bildiriminiz Treasurer / Başkan onayından sonra bakiyenize işlenir.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(
                enabled = !saving,
                onClick = {
                    val a = parseAmount(amount)
                    when {
                        member == null -> error = "Üye seçin."
                        a == null || a <= 0.0 -> error = "Geçerli bir tutar girin."
                        else -> {
                            saving = true
                            vm.addPayment(
                                Payment(
                                    memberId = member.id, date = date.toString(), amount = a, type = type,
                                    forMonth = if (type == PayType.AIDAT) ym else "",
                                    method = method, note = note.trim(), approved = admin, createdBy = me.id
                                ),
                                receiptUri
                            ) { vm.pop() }
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (admin) "Kaydet" else "Gönder") }
        }
    }
}

@Composable
fun ChargeAddScreen(vm: AppViewModel, d: AppData, memberId: String) {
    val member = d.members.firstOrNull { it.id == memberId }
    val types = PayType.entries.filter { it != PayType.AIDAT }
    var type by remember { mutableStateOf(PayType.YAMA) }
    var amount by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now()) }
    var error by remember { mutableStateOf<String?>(null) }

    Page("Ekstra borç yaz", onBack = { vm.pop() }) {
        FormColumn {
            KV("Üye", member?.display() ?: "-")
            PickerField("Tür", type.label, types.map { it.label to it }) { type = it }
            AmountField("Tutar (₺)", amount) { amount = it }
            FormField("Açıklama (örn. Haziran run katılım payı)", desc) { desc = it }
            DateField("Tarih", date) { date = it }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(
                onClick = {
                    val a = parseAmount(amount)
                    if (a == null || a <= 0.0) error = "Geçerli bir tutar girin."
                    else {
                        vm.addCharge(Charge(memberId = memberId, date = date.toString(), amount = a, type = type, description = desc.trim()))
                        vm.pop()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Kaydet") }
        }
    }
}

@Composable
fun LedgerAddScreen(vm: AppViewModel, d: AppData, income: Boolean) {
    val cats = if (income) INCOME_CATS else EXPENSE_CATS
    var cat by remember { mutableStateOf(cats[0]) }
    var account by remember { mutableStateOf(Account.NAKIT) }
    var scope by remember { mutableStateOf(Scope.CHARTER) }
    var amount by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now()) }
    var error by remember { mutableStateOf<String?>(null) }

    Page(if (income) "Gelir ekle" else "Gider ekle", onBack = { vm.pop() }) {
        FormColumn {
            PickerField("Kalem", cat, cats.map { it to it }) { cat = it }
            AmountField("Tutar (₺)", amount) { amount = it }
            PickerField("Hesap", account.label, Account.entries.map { it.label to it }) { account = it }
            PickerField("Kasa", scopeName(d.settings, scope), Scope.entries.map { scopeName(d.settings, it) to it }) { scope = it }
            FormField("Açıklama", desc) { desc = it }
            DateField("Tarih", date) { date = it }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(
                onClick = {
                    val a = parseAmount(amount)
                    if (a == null || a <= 0.0) error = "Geçerli bir tutar girin."
                    else {
                        vm.addLedger(
                            LedgerEntry(
                                date = date.toString(), amount = a, income = income, category = cat,
                                description = desc.trim(), account = account, scope = scope
                            )
                        )
                        vm.pop()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Kaydet") }
        }
    }
}

@Composable
fun ApprovalsScreen(vm: AppViewModel, d: AppData) {
    val list = d.payments.filter { !it.approved }.sortedBy { it.date }
    var receipt by remember { mutableStateOf<String?>(null) }
    Page("Onay bekleyen ödemeler", onBack = { vm.pop() }) {
        androidx.compose.foundation.lazy.LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { Spacer(Modifier.height(6.dp)) }
            if (list.isEmpty()) item { Text("Onay bekleyen ödeme yok.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(list.size) { i ->
                val p = list[i]
                val who = d.members.firstOrNull { it.id == p.memberId }?.display() ?: "Üye"
                KasaCard {
                    Text(who, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                    KV(
                        if (p.type == PayType.AIDAT) "Aidat – ${ymLabelOf(p.forMonth)}" else p.type.label,
                        money(p.amount), bold = true
                    )
                    Text("${fmtDate(p.date)} · ${p.method.label}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (p.note.isNotBlank()) Text(p.note, style = MaterialTheme.typography.bodySmall)
                    Row {
                        if (p.receipt.isNotBlank()) TextButton(onClick = { receipt = p.receipt }) { Text("Dekontu gör") }
                        TextButton(onClick = { vm.approve(p.id) }) { Text("Onayla") }
                        TextButton(onClick = { vm.reject(p.id) }) { Text("Reddet", color = Red) }
                    }
                }
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
    receipt?.let { ReceiptDialog(it) { receipt = null } }
}
