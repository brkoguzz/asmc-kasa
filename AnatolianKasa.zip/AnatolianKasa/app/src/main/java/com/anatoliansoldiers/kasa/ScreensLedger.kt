@file:OptIn(ExperimentalMaterial3Api::class)

package com.anatoliansoldiers.kasa

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.time.LocalDate

/** Android 13+ için bildirim iznini ilk açılışta bir kez ister. */
@Composable
fun AskNotificationPermission() {
    if (Build.VERSION.SDK_INT < 33) return
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) { launcher.launch(Manifest.permission.POST_NOTIFICATIONS) }
}

@Composable
fun LedgerScreen(vm: AppViewModel, d: AppData, admin: Boolean) {
    var scope by remember { mutableStateOf(Scope.CHARTER) }
    var delId by remember { mutableStateOf<String?>(null) }
    val nakit = Calc.accountBalance(d, scope, Account.NAKIT)
    val banka = Calc.accountBalance(d, scope, Account.BANKA)
    val year = LocalDate.now().year
    val from = LocalDate.of(year, 1, 1)
    val to = LocalDate.of(year, 12, 31)
    val entries = d.ledger.filter { it.scope == scope }.sortedByDescending { it.date }.take(150)

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Kulüp kasası", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp))
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Scope.entries.forEach { sc ->
                    FilterChip(
                        selected = scope == sc,
                        onClick = { scope = sc },
                        label = { Text(scopeName(d.settings, sc)) }
                    )
                }
            }
        }
        item {
            KasaCard {
                Text("Anlık bakiye – ${scopeName(d.settings, scope)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(money(nakit + banka), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                KV("Nakit kasa", money(nakit), balanceColor(nakit))
                KV("Banka hesabı", money(banka), balanceColor(banka))
            }
        }
        if (admin) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.push(Screen.LedgerAdd(true)) }, modifier = Modifier.weight(1f)) { Text("Gelir ekle") }
                    OutlinedButton(onClick = { vm.push(Screen.LedgerAdd(false)) }, modifier = Modifier.weight(1f)) { Text("Gider ekle") }
                }
            }
        }
        // Özet: tüm üyeler görür (kalem bazında toplamlar).
        val scoped = d.copy(ledger = d.ledger.filter { it.scope == scope })
        val inc = Calc.categoryTotals(scoped, true, from, to)
        val exp = Calc.categoryTotals(scoped, false, from, to)
        item {
            KasaCard {
                Text("$year yılı gelirleri", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                if (inc.isEmpty()) Text("Kayıt yok.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                inc.forEach { KV(it.first, money(it.second), Green) }
                if (inc.isNotEmpty()) KV("Toplam gelir", money(inc.sumOf { it.second }), Green, true)
            }
        }
        item {
            KasaCard {
                Text("$year yılı giderleri", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                if (exp.isEmpty()) Text("Kayıt yok.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                exp.forEach { KV(it.first, money(it.second), Red) }
                if (exp.isNotEmpty()) KV("Toplam gider", money(exp.sumOf { it.second }), Red, true)
            }
        }
        if (admin) {
            item { Title("Hareketler") }
            if (entries.isEmpty()) item { Text("Henüz kayıt yok.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(entries, key = { it.id }) { e ->
                Column {
                    LedgerRow(e)
                    if (e.paymentId.isBlank()) {
                        TextButton(onClick = { delId = e.id }) { Text("Sil") }
                    } else {
                        Text(
                            "Üye ödemesinden oluştu; silmek için üye ekranından ödemeyi silin.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(start = 4.dp, top = 2.dp)
                        )
                    }
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
    delId?.let { id ->
        ConfirmDialog("Kayıt silinsin mi?", "Bu işlem geri alınamaz.", "Sil", { vm.deleteLedger(id); delId = null }, { delId = null })
    }
}

@Composable
fun ReportScreen(d: AppData) {
    val ctx = LocalContext.current
    val now = LocalDate.now()
    var year by remember { mutableStateOf(now.year) }
    var month by remember { mutableStateOf<Int?>(null) }
    var msg by remember { mutableStateOf<String?>(null) }

    val from = if (month == null) LocalDate.of(year, 1, 1) else LocalDate.of(year, month!!, 1)
    val to = if (month == null) LocalDate.of(year, 12, 31) else from.withDayOfMonth(from.lengthOfMonth())
    val inc = Calc.categoryTotals(d, true, from, to)
    val exp = Calc.categoryTotals(d, false, from, to)
    val incT = inc.sumOf { it.second }
    val expT = exp.sumOf { it.second }

    fun run(block: () -> Unit) {
        try { block(); msg = null } catch (e: Exception) { msg = "Dosya oluşturulamadı: ${e.message}" }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Raporlar (Church toplantısı)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PickerField(
                "Yıl", year.toString(),
                (now.year downTo now.year - 5).map { it.toString() to it },
                Modifier.weight(1f)
            ) { year = it }
            PickerField(
                "Dönem", month?.let { TR_MONTHS[it - 1] } ?: "Tüm yıl",
                listOf("Tüm yıl" to null) + (1..12).map { TR_MONTHS[it - 1] to it },
                Modifier.weight(1f)
            ) { month = it }
        }
        KasaCard {
            Text("Dönem özeti", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            KV("Toplam gelir", money(incT), Green)
            KV("Toplam gider", money(expT), Red)
            KV("Sonuç", money(incT - expT), balanceColor(incT - expT), true)
        }
        Button(
            onClick = { run { Export.share(ctx, Export.pdfReport(ctx, d, year, month), "application/pdf", "Mali raporu paylaş") } },
            modifier = Modifier.fillMaxWidth()
        ) { Text("PDF mali rapor (kaydet / paylaş)") }
        OutlinedButton(
            onClick = { run { Export.share(ctx, Export.ledgerCsv(ctx, d, year, month), "text/csv", "Kasa hareketlerini paylaş") } },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Excel: kasa hareketleri") }
        OutlinedButton(
            onClick = { run { Export.share(ctx, Export.duesCsv(ctx, d, year), "text/csv", "Aidat tablosunu paylaş") } },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Excel: üye aidat tablosu ($year)") }
        Text(
            "Excel dosyaları .csv olarak oluşur; Excel ve Google Sheets doğrudan açar. Paylaşım menüsünden Drive, WhatsApp, e-posta veya \"Dosyalar\"a kaydedebilirsiniz.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        msg?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}

@Composable
fun SettingsScreen(vm: AppViewModel, d: AppData, me: Member) {
    val ctx = LocalContext.current
    val admin = Calc.isAdmin(me)
    var org by remember { mutableStateOf(d.settings.orgName) }
    var chapter by remember { mutableStateOf(d.settings.chapterName) }
    var dues by remember { mutableStateOf(fmtPlain(d.settings.defaultDues)) }
    var day by remember { mutableStateOf(d.settings.dueDay.toString()) }
    var msg by remember { mutableStateOf<String?>(null) }
    var confirmRestore by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val text = runCatching { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() }.getOrNull()
            if (text.isNullOrBlank()) msg = "Dosya okunamadı." else confirmRestore = text
        }
    }

    Page("Ayarlar", onBack = { vm.pop() }) {
        FormColumn {
            Text("${me.display()} · ${me.rankLabel()}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (admin) {
                Title("Kulüp ayarları")
                FormField("Kulüp adı", org) { org = it }
                FormField("Chapter adı", chapter) { chapter = it }
                AmountField("Varsayılan aylık aidat (₺)", dues) { dues = it }
                FormField("Aidat son ödeme günü (1-28)", day, KeyboardType.Number) { day = it.filter(Char::isDigit).take(2) }
                Button(
                    onClick = {
                        vm.updateSettings(
                            Settings(
                                org.trim().ifBlank { "Anatolian Soldiers MC" },
                                chapter.trim().ifBlank { "Hatay" },
                                parseAmount(dues) ?: 0.0,
                                (day.toIntOrNull() ?: 5).coerceIn(1, 28)
                            )
                        )
                        msg = "Ayarlar kaydedildi."
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Ayarları kaydet") }

                Title("Yedek")
                Text(
                    "Veriler yalnızca bu telefonda saklanır. Düzenli yedek alın; başka bir telefona geçerken veya diğer yöneticiyle paylaşırken yedek dosyasını kullanın.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedButton(
                    onClick = {
                        runCatching { Export.share(ctx, vm.backupFile(), "application/json", "Yedeği kaydet / paylaş") }
                            .onFailure { msg = "Yedek oluşturulamadı: ${it.message}" }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Yedek al (dosya olarak paylaş)") }
                OutlinedButton(onClick = { picker.launch("*/*") }, modifier = Modifier.fillMaxWidth()) {
                    Text("Yedekten geri yükle")
                }
            }
            msg?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
            Title("Oturum")
            OutlinedButton(onClick = { vm.logout() }, modifier = Modifier.fillMaxWidth()) { Text("Çıkış yap") }
        }
    }
    confirmRestore?.let { text ->
        ConfirmDialog(
            "Yedek geri yüklensin mi?",
            "Bu telefondaki mevcut tüm kayıtlar yedekteki verilerle değiştirilir.",
            "Geri yükle",
            {
                msg = if (vm.importBackup(text)) "Yedek geri yüklendi." else "Geçersiz yedek dosyası."
                confirmRestore = null
            },
            { confirmRestore = null }
        )
    }
}
