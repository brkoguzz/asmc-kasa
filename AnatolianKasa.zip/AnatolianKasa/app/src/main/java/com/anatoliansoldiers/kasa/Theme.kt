package com.anatoliansoldiers.kasa

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Amber = Color(0xFFE8A317)
val Green = Color(0xFF3FB950)
val Red = Color(0xFFE5484D)
val GrayC = Color(0xFF8A8A8A)

private val Scheme = darkColorScheme(
    primary = Amber,
    onPrimary = Color(0xFF1A1200),
    primaryContainer = Color(0xFF3A2A00),
    onPrimaryContainer = Color(0xFFFFE2A0),
    secondary = Color(0xFFC9A24A),
    onSecondary = Color(0xFF1A1200),
    background = Color(0xFF0E0E0E),
    onBackground = Color(0xFFEDEDED),
    surface = Color(0xFF151515),
    onSurface = Color(0xFFEDEDED),
    surfaceVariant = Color(0xFF222222),
    onSurfaceVariant = Color(0xFFB8B8B8),
    outline = Color(0xFF555555),
    error = Red
)

@Composable
fun KasaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
