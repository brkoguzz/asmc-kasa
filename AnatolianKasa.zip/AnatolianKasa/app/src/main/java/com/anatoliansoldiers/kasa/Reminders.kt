package com.anatoliansoldiers.kasa

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.YearMonth
import java.util.concurrent.TimeUnit

object Reminders {
    private const val CHANNEL = "aidat"

    /** Her gün 10:00 civarında bir kez çalışacak yerel hatırlatma görevi. */
    fun schedule(ctx: Context) {
        val now = LocalDateTime.now()
        var next = now.toLocalDate().atTime(10, 0)
        if (!next.isAfter(now)) next = next.plusDays(1)
        val delayMin = Duration.between(now, next).toMinutes()
        val req = PeriodicWorkRequestBuilder<ReminderWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(delayMin, TimeUnit.MINUTES)
            .build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("aidat-hatirlatma", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    fun notify(ctx: Context, id: Int, title: String, text: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Aidat hatırlatmaları", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val pi = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_kasa)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(id, n)
    }
}

class ReminderWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("session", Context.MODE_PRIVATE)
        val memberId = prefs.getString("memberId", null) ?: return Result.success()
        val d = Repository(applicationContext).load()
        val me = d.members.firstOrNull { it.id == memberId } ?: return Result.success()
        val today = LocalDate.now()

        if (Calc.isAdmin(me)) {
            val late = d.members.filter { it.status == MemberStatus.AKTIF && Calc.overdueAmount(d, it, today) > 0.005 }
            val pending = d.payments.count { !it.approved }
            if (late.isNotEmpty() && today.dayOfMonth > d.settings.dueDay) {
                val sum = late.sumOf { Calc.overdueAmount(d, it, today) }
                Reminders.notify(
                    applicationContext, 1, "Geciken aidatlar",
                    "${late.size} üyenin aidatı gecikmede (toplam ${money(sum)})."
                )
            }
            if (pending > 0) {
                Reminders.notify(applicationContext, 2, "Onay bekleyen ödemeler", "$pending ödeme onayınızı bekliyor.")
            }
        } else {
            val b = Calc.balance(d, me, today)
            val st = Calc.monthState(d, me, YearMonth.from(today), today)
            val daysLeft = d.settings.dueDay - today.dayOfMonth
            when {
                Calc.overdueAmount(d, me, today) > 0.005 ->
                    Reminders.notify(
                        applicationContext, 3, "Aidat gecikmesi",
                        "Gecikmiş aidat borcunuz: ${money(Calc.overdueAmount(d, me, today))}. Lütfen Treasurer ile görüşün."
                    )
                st == MonthState.DUE && daysLeft in 0..3 ->
                    Reminders.notify(
                        applicationContext, 4, "Aidat günü yaklaşıyor",
                        "Bu ayki aidat (${money(b.current)}) için son gün ayın ${d.settings.dueDay}. günü."
                    )
            }
        }
        return Result.success()
    }
}
