package com.anatoliansoldiers.kasa

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

@Composable
fun SetupScreen(vm: AppViewModel) {
    var org by remember { mutableStateOf("Anatolian Soldiers MC") }
    var chapter by remember { mutableStateOf("Hatay") }
    var dues by remember { mutableStateOf("") }
    var dueDay by remember { mutableStateOf("5") }
    var name by remember { mutableStateOf("") }
    var road by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.fillMaxSize().systemBarsPadding().imePadding()
            .verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("İlk kurulum", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(
            "Bu telefonda kasa kaydını başlatıyorsunuz. Kurulumu yapan kişi Treasurer (Sayman) olarak eklenir ve yönetici yetkisine sahip olur.",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        FormField("Kulüp adı", org) { org = it }
        FormField("Chapter (Şube)", chapter) { chapter = it }
        AmountField("Varsayılan aylık aidat (₺)", dues) { dues = it }
        FormField("Aidat son ödeme günü (1-28)", dueDay, KeyboardType.Number) { dueDay = it.filter(Char::isDigit).take(2) }
        Title("Yönetici (Treasurer)")
        FormField("Ad Soyad", name) { name = it }
        FormField("Road Name (Yol Adı)", road) { road = it }
        PinField("Giriş PIN'i (4-6 rakam)", pin) { pin = it }
        PinField("PIN tekrar", pin2) { pin2 = it }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(
            onClick = {
                val amount = parseAmount(dues) ?: 0.0
                val day = (dueDay.toIntOrNull() ?: 5).coerceIn(1, 28)
                when {
                    name.isBlank() -> error = "Ad Soyad gerekli."
                    pin.length < 4 -> error = "PIN en az 4 rakam olmalı."
                    pin != pin2 -> error = "PIN'ler aynı değil."
                    else -> vm.setup(org.trim(), chapter.trim(), amount, day, name.trim(), road.trim(), pin)
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Kurulumu tamamla") }
    }
}

@Composable
fun LoginScreen(vm: AppViewModel, d: AppData) {
    var sel by remember { mutableStateOf<String?>(null) }
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val members = d.members.sortedBy { it.fullName }

    Column(
        Modifier.fillMaxSize().systemBarsPadding().imePadding()
            .verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            d.settings.orgName.uppercase(),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text("${d.settings.chapterName} Charter Kasası", style = MaterialTheme.typography.titleMedium)
        PickerField(
            "Üye",
            members.firstOrNull { it.id == sel }?.display() ?: "Seçiniz",
            members.map { it.display() to it.id }
        ) { sel = it; error = null }
        PinField("PIN", pin) { pin = it; error = null }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(
            onClick = {
                val s = sel
                if (s == null) error = "Önce üyeyi seçin."
                else if (!vm.login(s, pin)) error = "PIN hatalı."
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Giriş") }
        Text(
            "PIN'inizi unuttuysanız Treasurer veya Başkan üye kaydınızdan yeni PIN belirleyebilir.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodySmall
        )
    }
}
